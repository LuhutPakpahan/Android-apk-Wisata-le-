package com.example.dicodingsubmission

data class Univ (
    var name: String = "",
    var rank: String = "",
    var photo: String = "",
    var overview: String = "",
    var identity: String = ""

)