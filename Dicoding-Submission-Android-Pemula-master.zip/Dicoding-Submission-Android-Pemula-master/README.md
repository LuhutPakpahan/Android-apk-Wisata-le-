# Dicoding Submission Android Pemula
Submission - Belajar membuat aplikasi android untuk pemula dicoding

## Motivation
This is a project for my learning record and this is a android beginner submission final assignment [dicoding](https://www.dicoding.com/academies/51)

## Screenshots
<img src="https://raw.githubusercontent.com/rizalfahrudin879/DicodingSubmissionAndroidPemula/master/Screenshot_2019-08-11-13-43-06-59_4d0e63c27277ba34a664d196aaa6634e.png"
     alt="Home Screen"
     style="float: left; margin-right: 10px;"
     width="200" /> <img src="https://raw.githubusercontent.com/rizalfahrudin879/DicodingSubmissionAndroidPemula/master/Screenshot_2019-08-11-13-43-20-25_4d0e63c27277ba34a664d196aaa6634e.png"
     alt="Detail Screen"
     style="float: left; margin-right: 10px;"
     width="200" /> <img src="https://raw.githubusercontent.com/rizalfahrudin879/DicodingSubmissionAndroidPemula/master/Screenshot_2019-08-11-13-43-28-03_4d0e63c27277ba34a664d196aaa6634e.png"
     alt="About Screen"
     style="float: left; margin-right: 10px;"
     width="200" />
     
 ## Features
#### Submission Checklists
- [x] Display images and information in the Format list
- [x] A detail page appears when an item is clicked
- [x] Display images and information on the detail page
- [x] Display page about

## Installation
Clone this repository and import into Android Studio
```
https://github.com/rizalfahrudin879/DicodingSubmissionAndroidPemula.git
```
## Author
* #### Rizal Fahrudin
